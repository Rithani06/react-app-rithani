/** @jsx React.DOM */
var React = require('react/addons');
var App = require('./App.js');
React.render(<App/>, document.body);